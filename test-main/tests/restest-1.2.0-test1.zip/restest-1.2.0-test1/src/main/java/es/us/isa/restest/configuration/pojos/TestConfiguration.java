
package es.us.isa.restest.configuration.pojos;

import java.util.List;

public class TestConfiguration {

    private List<Operation> operations = null;

    public List<Operation> getOperations() {
        return operations;
    }

    public void setOperations(List<Operation> operations) {
        this.operations = operations;
    }

}
