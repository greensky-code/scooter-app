
package es.us.isa.restest.configuration.pojos;


public class TestConfigurationObject {

    private Auth auth;
    private TestConfiguration testConfiguration;

    public Auth getAuth() {
        return auth;
    }

    public void setAuth(Auth auth) {
        this.auth = auth;
    }

    public TestConfiguration getTestConfiguration() {
        return testConfiguration;
    }

    public void setTestConfiguration(TestConfiguration testConfiguration) {
        this.testConfiguration = testConfiguration;
    }

}
